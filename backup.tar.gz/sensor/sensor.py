import sqlite3
from neo import easyGpio
from neo_adc import ADC
from threading import Thread
from threading import Lock
from time import time, sleep


class SensorServer(Thread):
        def __init__(self, db_file = "realaqi.db"):
                Thread.__init__(self)

                # assign GPIO pins that control mux selector pins
                # (If you're using a GPIO)


                self.mux = [easyGpio(24), easyGpio(25), easyGpio(26), easyGpio(27)]

		for sel in self.mux:
                	sel.pinOUT()


                # initialize ADC library to read ADC value(s)
		self.A0 = ADC(0)
		self.A1 = ADC(1)	

                self.sensor_output = {
                        "type" : "real",
			"timestamp" : 0.,
                        "so2" : 0.,
                        "co" : 0.,
                        "no2" : 0.,
                        "o3" : 0.,
                        "pm25" : 0.,
                        "temp" : 0.
                }

                self.sensor_output_lock = Lock()
                self.db_file = db_file

                try:
                        self.db_conn = sqlite3.connect(self.db_file,check_same_thread=False)
                        self.db_cur = self.db_conn.cursor()
                except Exception as e:
                        print "ERROR (sensor.py) : {}".format(repr(e))
                        self.__del__()

                #execute query to create table using IF NOT EXISTS keywords
                self.db_cur.execute("CREATE TABLE IF NOT EXISTS history (type TEXT, timestamp INT ,so2 REAL, co REAL, no2 REAL, o3 REAL, pm25 REAL, temp REAL)")
		self.db_conn.commit()

        def __del__(self):
                self.db_conn.close()
                # if you're using a mux, reset all selector pins to LOW
        def get_sensor_output(self):
                return self.sensor_output.copy()

        def set_mux_channel(self,ch):
                bits = "{0:04b}".format(ch)
                # change 4 selector pins depending on value of ch
                for i in range(0,4):
                        bit = int(bits[3-i])
                        sel = self.mux[3-i]
                        sel.on() if bit else sel.off()

        def run(self):
                while True:
                        # acquire the lock
                        self.sensor_output_lock.acquire()

                        # get the current time
                        current_time = int(time())

                        # read from all sensors
                        self.set_mux_channel(0)
                        sleep(0.5)
                        NO2_WE = self.A0.get_mvolts()



                        self.set_mux_channel(1)
                        sleep(0.5)
                        NO2_AE = self.A0.get_mvolts()

                        self.set_mux_channel(2)
                        sleep(0.5)
                        O3_WE = self.A0.get_mvolts()


                        self.set_mux_channel(3)
                        sleep(0.5)
                        O3_AE = self.A0.get_mvolts()


                        self.set_mux_channel(4)
                        sleep(0.5)
                        CO_WE = self.A0.get_mvolts()

                        self.set_mux_channel(5)
                        sleep(0.5)
                        CO_AE = self.A0.get_mvolts()



                        self.set_mux_channel(6)
                        sleep(0.5)
                        SO2_WE = self.A0.get_mvolts()



                        self.set_mux_channel(7)
                        sleep(0.5)
                        SO2_AE = self.A0.get_mvolts()


                        temp_measure = self.A1.get_mvolts()

                        self.set_mux_channel(9)
                        sleep(0.5)
                        pm = self.A0.get_mvolts()

                        # caculate ppb or ug/m^3

			timestamp = int(time())
                        no2 = ((NO2_WE - 220) - (1.18 * (NO2_AE - 260))) / 0.207
                        o3 = ((O3_WE - 414) - (0.18 * (O3_AE - 400))) / 0.256
                        co = ((CO_WE - 346) - (0.03 * (CO_AE - 274))) / 0.27
                        so2 = ((SO2_WE - 300) - (1.15 * (SO2_AE - 294))) / 0.300
                        temp = ((temp_measure * 0.004882814) - 0.5) * 5
                        mV = pm/1000
                        hppcf = (240. * (mV ** 6)) - (2491.3 * (mV ** 5)) + (944.87 * (mV ** 4)) - (14840 * (mV ** 3)) + (10684 * (mV ** 2)) + (2211.8 * mV) + 7.9623
                        pm25 = 0.518 + 0.00274 * hppcf
			if (pm25 < 0) :
				pm25 *= -1


                        # update the dictionary

                        self.sensor_output["type"] = "real"
                        self.sensor_output["timestamp"] = timestamp
			self.sensor_output["so2"] = so2
                        self.sensor_output["co"] = co
                        self.sensor_output["no2"] = no2
                        self.sensor_output["o3"] = o3
                        self.sensor_output["pm25"] = pm25
                        self.sensor_output["temp"] = temp



                        # insert ne values into the database
                        self.db_cur.execute("INSERT INTO history VALUES (?, ?, ?, ?, ?, ?, ?, ?)",("real", timestamp, so2, co, no2, o3, pm25, temp))
                        self.db_conn.commit()


                        for row in self.db_cur.execute("SELECT * FROM history"):
                                 print row


                        # release the lock
                        self.sensor_output_lock.release()

                        sleep(1)






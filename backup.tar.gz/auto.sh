sudo service bluetooth restart

sudo hciconfig hci0 piscan

sudo sdptool add sp
